import 'package:flutter/cupertino.dart';
import 'package:shop_app_simple_1/models/auth_model.dart';
import 'package:shop_app_simple_1/services/services.dart';

class AuthProvider extends ChangeNotifier{
  AuthModel? user;

  Future<bool> logUser({
    required String email,
    required String password,
  })async{
      final response = await AuthService.signIn(email: email, password: password);
      notifyListeners();
      return response != null;
  }

}